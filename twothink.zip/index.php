<?php
/*twothink.cn 艺品网络ss*/
header("Location: http://". $_SERVER['SERVER_NAME'] . rtrim(dirname(rtrim($_SERVER['SCRIPT_NAME'], '/')), '/').'/public' );exit();
?>