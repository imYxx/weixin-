<?php
// +----------------------------------------------------------------------
// | TwoThink [ WE CAN DO IT JUST THINK IT ]
// +----------------------------------------------------------------------
// | Copyright (c) 2016 http://www.twothink.cn All rights reserved.
// +----------------------------------------------------------------------
// | Author: 艺品网络 
// +----------------------------------------------------------------------

namespace app\admin\Model;
use think\Model;
/**
 * 权限规则模型 
 */
class AuthRule extends Model{
    
    const rule_url = 1;
    const rule_main = 2;

}
