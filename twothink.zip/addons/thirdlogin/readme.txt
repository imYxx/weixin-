﻿

在首页需要显示QQ图标的地方加入钩子

{:hook('thirdlogin')}
